visual studio
создаем проект библиотека классов (c#)
проект называем ClassLibraryPassword
перебиваем код из первого фото
выделить validatePassword нажать правой кнопкой мыши выбрать создание модульных тестов нажать ок
появится файл ...test в него перепечатать код с фото 2
![image](https://user-images.githubusercontent.com/90445300/133395782-de7403b3-0910-48ce-93a1-8231f2e0ab1d.png)
![image](https://user-images.githubusercontent.com/90445300/133395833-dbe880c9-b890-47bf-b4c5-34674775c9e6.png)
![image](https://user-images.githubusercontent.com/90445300/133399220-fd3dbf2a-f90b-424a-8c32-b2261d671a56.png)

